# Cloudflare deployment

This package uses a Cloudflare Worker with Static Assets and a 15-minute Cron Trigger.

## Dashboard
Create a Worker and deploy the package using the Worker deployment flow. The entry point is `_worker.js/index.js` and `wrangler.jsonc` contains the `*/15 * * * *` Cron Trigger.

## Important data-source note
The scheduled job fetches the official TNEB/TNPDCL CPRO shutdown page. The newer TNPDCL outage portal can require CAPTCHA, so it cannot be reliably scraped automatically when CAPTCHA is presented. The site should therefore treat the official outage portal as the final authority.

The fetched feed is stored in Cloudflare's edge Cache API and refreshed every 15 minutes by the Cron Trigger. If the cache is evicted, the next website request rebuilds the feed.
