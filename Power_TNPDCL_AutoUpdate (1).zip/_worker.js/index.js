import server from "./server/index.mjs";

const CACHE_URL = "https://tnebpowercut.in/__internal/shutdown-feed.json";
const CACHE_TTL_SECONDS = 60 * 60 * 24;
const SERVER_FN_ID = "73c3b00b00b30ff89c72ce467aa6f1e81616a0a130b75690ab1f5bc3fbb70643";
const NEWS_QUERIES = [
  '"power shutdown" Tamil Nadu',
  '"power cut" TNPDCL areas',
  '"electricity supply will be suspended" Tamil Nadu',
  '"power supply" "will be suspended" TANGEDCO',
  '"power shutdown" district Tamil Nadu areas',
  "மின்தடை தமிழ்நாடு"
];

function decode(s) {
  let out = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  for (let i = 0; i < 2; i++) {
    out = out.replace(/&nbsp;/g, " ").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/<[^>]*>/g, " ");
  }
  return out.replace(/\s+/g, " ").trim();
}

const DISTRICTS = {
  chennai: ["chennai"], coimbatore: ["coimbatore"], madurai: ["madurai"], salem: ["salem"],
  tiruchirappalli: ["tiruchirappalli", "trichy"], tiruppur: ["tiruppur"], erode: ["erode"],
  vellore: ["vellore"], tirunelveli: ["tirunelveli"], thoothukudi: ["thoothukudi", "tuticorin"],
  kancheepuram: ["kancheepuram", "kanchipuram"], chengalpattu: ["chengalpattu"],
  tiruvallur: ["tiruvallur"], ranipet: ["ranipet"], krishnagiri: ["krishnagiri"],
  dharmapuri: ["dharmapuri"], namakkal: ["namakkal"], karur: ["karur"], thanjavur: ["thanjavur"],
  nagapattinam: ["nagapattinam"], mayiladuthurai: ["mayiladuthurai"], cuddalore: ["cuddalore"],
  villupuram: ["villupuram"], kallakurichi: ["kallakurichi"], dindigul: ["dindigul"],
  sivaganga: ["sivaganga"], ramanathapuram: ["ramanathapuram"], virudhunagar: ["virudhunagar"],
  theni: ["theni"], pudukkottai: ["pudukkottai"], perambalur: ["perambalur"], ariyalur: ["ariyalur"],
  tirupattur: ["tirupattur"], nilgiris: ["nilgiris", "ooty"], tenkasi: ["tenkasi"]
};

function matchPlaces(text) {
  const lower = text.toLowerCase();
  const districtSlugs = [];
  for (const [slug, names] of Object.entries(DISTRICTS)) {
    if (names.some((name) => lower.includes(name))) districtSlugs.push(slug);
  }
  const places = text.split(/[,;|]+/).map((x) => x.trim()).filter((x) => x.length >= 3 && x.length <= 80).slice(0, 20);
  return { districtSlugs, places };
}

async function fetchText(url, ms = 12000) {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(ms),
      headers: { "user-agent": "tnebpowercut.in/1.0 (+https://tnebpowercut.in)" }
    });
    if (!res.ok) return null;
    return await res.text();
  } catch { return null; }
}

function parseRss(xml, sourceLabel) {
  const items = xml.match(/<item>[\s\S]*?<\/item>/g) ?? [];
  return items.map((item) => {
    const title = decode(item.match(/<title>([\s\S]*?)<\/title>/)?.[1] ?? "");
    const link = decode(item.match(/<link>([\s\S]*?)<\/link>/)?.[1] ?? "");
    const pub = decode(item.match(/<pubDate>([\s\S]*?)<\/pubDate>/)?.[1] ?? "");
    const desc = decode(item.match(/<description>([\s\S]*?)<\/description>/)?.[1] ?? "");
    if (!title || !link) return null;
    const date = pub ? new Date(pub) : new Date();
    if (Number.isNaN(date.getTime())) return null;
    const { districtSlugs, places } = matchPlaces(`${title} ${desc}`);
    return { id: link, title, summary: desc.slice(0, 260), link, source: sourceLabel, publishedAt: date.toISOString(), districtSlugs, places };
  }).filter(Boolean);
}

async function fetchOfficialCpro() {
  const html = await fetchText("https://tneb.tnebnet.org/cpro/today.html");
  if (!html) return [];
  const rows = html.match(/<tr>[\s\S]*?<\/tr>/gi) ?? [];
  const out = [];
  for (const row of rows) {
    const cells = (row.match(/<td[\s\S]*?<\/td>/gi) ?? []).map(decode).filter(Boolean);
    if (cells.length < 2) continue;
    const dateText = cells[0];
    const area = cells.slice(1).join(" — ");
    if (!/\d/.test(dateText) || area.length < 6) continue;
    const parts = dateText.split(/[-/]/);
    if (parts.length < 3) continue;
    const [dd, mm, yy] = parts;
    const iso = new Date(`20${String(yy).slice(-2)}-${mm.padStart(2,"0")}-${dd.padStart(2,"0")}T09:00:00+05:30`);
    if (Number.isNaN(iso.getTime())) continue;
    const { districtSlugs, places } = matchPlaces(area);
    out.push({
      id: `cpro-${dateText}-${area.slice(0, 80)}`,
      title: `Planned shutdown 09:00–14:00 — ${area.slice(0, 120)}`,
      summary: area.slice(0, 400),
      link: "https://tneb.tnebnet.org/cpro/today.html",
      source: "TNPDCL/TNEB CPRO (official)",
      publishedAt: iso.toISOString(),
      districtSlugs: districtSlugs.length ? districtSlugs : ["chennai"],
      places
    });
  }
  return out;
}

async function buildFeed() {
  const official = await fetchOfficialCpro();
  const news = (await Promise.all(NEWS_QUERIES.map(async (q) => {
    const xml = await fetchText(`https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=en-IN&gl=IN&ceid=IN:en`);
    return xml ? parseRss(xml, "Tamil Nadu media") : [];
  }))).flat();
  const all = [...official, ...news];
  const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const seen = new Set();
  const notices = all.filter((n) => new Date(n.publishedAt).getTime() > cutoff).filter((n) => {
    const key = n.title.toLowerCase().slice(0, 90);
    if (seen.has(key)) return false;
    seen.add(key); return true;
  }).sort((a,b) => b.publishedAt.localeCompare(a.publishedAt)).slice(0, 200);
  return {
    fetchedAt: new Date().toISOString(),
    notices,
    sources: [
      { name: "TNPDCL/TNEB CPRO (official)", ok: official.length > 0, count: official.length },
      { name: "Tamil Nadu media", ok: news.length > 0, count: news.length }
    ]
  };
}

async function loadStoredFeed() {
  const hit = await caches.default.match(CACHE_URL);
  if (!hit) return null;
  try { return await hit.json(); } catch { return null; }
}

async function storeFeed(feed) {
  const response = new Response(JSON.stringify(feed), {
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": `public, max-age=${CACHE_TTL_SECONDS}` }
  });
  await caches.default.put(CACHE_URL, response);
  return feed;
}

async function refreshFeed() {
  const feed = await buildFeed();
  return storeFeed(feed);
}

async function getFeed() {
  const stored = await loadStoredFeed();
  if (stored) return stored;
  try { return await refreshFeed(); }
  catch { return { fetchedAt: new Date().toISOString(), notices: [], sources: [] }; }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    // TanStack Start server-function endpoint used by the shutdown pages.
    if (url.pathname === `/ _serverFn/${SERVER_FN_ID}`.replace(" ", "")) {
      const feed = await getFeed();
      return new Response(JSON.stringify(feed), { headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
    }
    return server.fetch(request, env, ctx);
  },
  async scheduled(controller, env, ctx) {
    ctx.waitUntil(refreshFeed());
  }
};
